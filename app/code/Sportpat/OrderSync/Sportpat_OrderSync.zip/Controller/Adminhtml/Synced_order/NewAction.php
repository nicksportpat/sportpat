<?php
namespace Sportpat\OrderSync\Controller\Adminhtml\Synced_order;

use Sportpat\OrderSync\Controller\Adminhtml\AbstractNewAction;

class NewAction extends AbstractNewAction
{

}
