<?php
namespace Sportpat\OrderSync\Controller\Adminhtml\Synced_order;

use Sportpat\OrderSync\Controller\Adminhtml\AbstractIndex;

class Index extends AbstractIndex
{

}
