<?php
namespace Sportpat\OrderSync\Controller\Adminhtml\SyncedOrder;

use Sportpat\OrderSync\Api\SyncedOrderRepositoryInterface;
use Sportpat\OrderSync\Api\Data\SyncedOrderInterface;
use Sportpat\OrderSync\Api\Data\SyncedOrderInterfaceFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\Registry;

/**
 * Class Save
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends Action
{
    /**
     * Synced Order factory
     * @var Synced_orderInterfaceFactory
     */
    protected $syncedOrderFactory;
    /**
     * Data Object Processor
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;
    /**
     * Data Object Helper
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;
    /**
     * Data Persistor
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    /**
     * Core registry
     * @var Registry
     */
    protected $registry;
    /**
     * Synced Order repository
     * @var Synced_orderRepositoryInterface
     */
    protected $synced_orderRepository;

    /**
     * Save constructor.
     * @param Context $context
     * @param SyncedOrderInterfaceFactory $syncedOrderFactory
     * @param SyncedOrderRepositoryInterface $syncedOrderRepository
     * @param DataObjectProcessor $dataObjectProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param DataPersistorInterface $dataPersistor
     * @param Registry $registry
     */
    public function __construct(
        Context $context,
        SyncedOrderInterfaceFactory $syncedOrderFactory,
        SyncedOrderRepositoryInterface $syncedOrderRepository,
        DataObjectProcessor $dataObjectProcessor,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
        Registry $registry
    ) {
        $this->syncedOrderFactory = $syncedOrderFactory;
        $this->syncedOrderRepository = $syncedOrderRepository;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
        $this->registry = $registry;
        parent::__construct($context);
    }

    /**
     * run the action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var Synced_orderInterface $synced_order */
        $syncedOrder = null;
        $postData = $this->getRequest()->getPostValue();
        $data = $postData;
        $id = !empty($data['synced_order_id']) ? $data['synced_order_id'] : null;
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            if ($id) {
                $syncedOrder = $this->syncedOrderRepository->get((int)$id);
            } else {
                unset($data['synced_order_id']);
                $syncedOrder = $this->syncedOrderFactory->create();
            }
            $this->dataObjectHelper->populateWithArray($syncedOrder, $data, SyncedOrderInterface::class);
            $this->syncedOrderRepository->save($syncedOrder);
            $this->messageManager->addSuccessMessage(__('You saved the Synced Order'));
            $this->dataPersistor->clear('sportpat_order_sync_synced_order');
            if ($this->getRequest()->getParam('back')) {
                $resultRedirect->setPath('*/*/edit', ['synced_order_id' => $syncedOrder->getId()]);
            } else {
                $resultRedirect->setPath('*/*');
            }
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
            $this->dataPersistor->set('sportpat_order_sync_synced_order', $postData);
            $resultRedirect->setPath('*/*/edit', ['synced_order_id' => $id]);
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('There was a problem saving the Synced Order'));
            $this->dataPersistor->set('sportpat\order_sync_synced_order', $postData);
            $resultRedirect->setPath('*/*/edit', ['synced_order_id' => $id]);
        }
        return $resultRedirect;
    }
}
