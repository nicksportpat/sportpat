<?php
namespace Sportpat\OrderSync\Controller\Adminhtml\Synced_order;

use Sportpat\OrderSync\Api\Synced_orderRepositoryInterface;
use Sportpat\OrderSync\Api\Data\Synced_orderInterface;
use Sportpat\OrderSync\Model\ResourceModel\Synced_order as Synced_orderResourceModel;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class InlineEdit
 */
class InlineEdit extends Action
{
    /**
     * Synced Order repository
     * @var Synced_orderRepositoryInterface
     */
    protected $synced_orderRepository;
    /**
     * Data object processor
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;
    /**
     * Data object helper
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;
    /**
     * JSON Factory
     * @var JsonFactory
     */
    protected $jsonFactory;
    /**
     * Synced Order resource model
     * @var Synced_orderResourceModel
     */
    protected $syncedOrderResourceModel;

    /**
     * constructor
     * @param Context $context
     * @param SyncedOrderRepositoryInterface $syncedOrderRepository
     * @param DataObjectProcessor $dataObjectProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param JsonFactory $jsonFactory
     * @param SyncedOrderResourceModel $syncedOrderResourceModel
     */
    public function __construct(
        Context $context,
        SyncedOrderRepositoryInterface $syncedOrderRepository,
        DataObjectProcessor $dataObjectProcessor,
        DataObjectHelper $dataObjectHelper,
        JsonFactory $jsonFactory,
        SyncedOrderResourceModel $syncedOrderResourceModel
    ) {
        $this->syncedOrderRepository = $syncedOrderRepository;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->jsonFactory = $jsonFactory;
        $this->syncedOrderResourceModel = $syncedOrderResourceModel;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];

        $postItems = $this->getRequest()->getParam('items', []);
        if (!($this->getRequest()->getParam('isAjax') && count($postItems))) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }

        foreach (array_keys($postItems) as $syncedOrderId) {
            /** @var \Sportpat\OrderSync\Model\Synced_order|\Sportpat\OrderSync\Api\Data\Synced_orderInterface $syncedOrder */
            try {
                $syncedOrder = $this->syncedOrderRepository->get((int)$syncedOrderId);
                $syncedOrderData = $postItems[$syncedOrderId];
                $this->dataObjectHelper->populateWithArray($syncedOrder, $syncedOrderData, SyncedOrderInterface::class);
                $this->syncedOrderResourceModel->saveAttribute($syncedOrder, array_keys($syncedOrderData));
            } catch (LocalizedException $e) {
                $messages[] = $this->getErrorWithSyncedOrderId($syncedOrder, $e->getMessage());
                $error = true;
            } catch (\RuntimeException $e) {
                $messages[] = $this->getErrorWithSyncedOrderId($syncedOrder, $e->getMessage());
                $error = true;
            } catch (\Exception $e) {
                $messages[] = $this->getErrorWithSyncedOrderId(
                    $syncedOrder,
                    __('Something went wrong while saving the Synced Order.')
                );
                $error = true;
            }
        }

        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }

    /**
     * Add Synced Order id to error message
     *
     * @param \Sportpat\OrderSync\Api\Data\Synced_orderInterface $syncedOrder
     * @param string $errorText
     * @return string
     */
    protected function getErrorWithSyncedOrderId(SyncedOrderInterface $syncedOrder, $errorText)
    {
        return '[Synced Order ID: ' . $syncedOrder->getId() . '] ' . $errorText;
    }
}
