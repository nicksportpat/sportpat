<?php
namespace Sportpat\OrderSync\Controller\Adminhtml\Synced_order;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Sportpat\OrderSync\Api\Synced_orderRepositoryInterface;

class Edit extends Action
{
    /**
     * @var Synced_orderRepositoryInterface
     */
    private $syncedOrderRepository;
    /**
     * @var Registry
     */
    private $registry;

    /**
     * Edit constructor.
     * @param Context $context
     * @param Synced_orderRepositoryInterface $syncedOrderRepository
     * @param Registry $registry
     */
    public function __construct(
        Context $context,
        Synced_orderRepositoryInterface $syncedOrderRepository,
        Registry $registry
    ) {
        $this->syncedOrderRepository = $syncedOrderRepository;
        $this->registry = $registry;
        parent::__construct($context);
    }

    /**
     * get current Synced Order
     *
     * @return null|\Sportpat\OrderSync\Api\Data\Synced_orderInterface
     */
    private function initSynced_order()
    {
        $syncedOrderId = $this->getRequest()->getParam('synced_order_id');
        try {
            $syncedOrder = $this->syncedOrderRepository->get($syncedOrderId);
        } catch (NoSuchEntityException $e) {
            $syncedOrder = null;
        }
        $this->registry->register('current_synced_order', $syncedOrder);
        return $syncedOrder;
    }

    /**
     * Edit or create Synced Order
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $syncedOrder = $this->initSyncedOrder();
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Sportpat_OrderSync::ordersync_synced_order');
        $resultPage->getConfig()->getTitle()->prepend(__('Synced Orders'));

        if ($syncedOrder === null) {
            $resultPage->getConfig()->getTitle()->prepend(__('New Synced Order'));
        } else {
            $resultPage->getConfig()->getTitle()->prepend($syncedOrder->getMagentoOrderid());
        }
        return $resultPage;
    }
}
