<?php
namespace Sportpat\OrderSync\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * install tables
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $this->createSynced_orderTable($setup);
        $installer->endSetup();
    }

    /**
     * install table for Synced Order
     *
     * @param SchemaSetupInterface $setup
     * @throws \Zend_Db_Exception
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    private function createSynced_orderTable(SchemaSetupInterface $setup)
    {
        if (!$setup->tableExists('sportpat_order_sync_synced_order')) {
            $table = $setup->getConnection()->newTable(
                $setup->getTable('sportpat_order_sync_synced_order')
            )
            ->addColumn(
                'synced_order_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'nullable' => false,
                    'primary'  => true,
                    'unsigned' => true,
                ],
                'Synced Order ID'
            )
            ->addColumn(
                'magento_orderid',
                Table::TYPE_INTEGER,
                null,
                [
                    'nullable' => false,
                ],
                'Synced Order Magento Order id'
            )
            ->addColumn(
                'lightspeed_orderid',
                Table::TYPE_INTEGER,
                null,
                [
                ],
                'Synced Order Lightspeed Order id'
            )
            ->addColumn(
                'sync_status',
                Table::TYPE_INTEGER,
                null,
                [
                ],
                'Synced Order Sync Status'
            )
            ->addColumn(
                'lightspeed_order_url',
                Table::TYPE_TEXT,
                null,
                [
                ],
                'Synced Order Lightspeed Order Link'
            )
            ->addColumn(
                'status_details',
                Table::TYPE_TEXT,
                null,
                [
                ],
                'Synced Order Status Details'
            )
            ->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => Table::TIMESTAMP_INIT
                ],
                'Synced Order Created At'
            )
            ->addColumn(
                'updated_at',
                Table::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => Table::TIMESTAMP_INIT_UPDATE
                ],
                'Synced Order Updated At'
            )
            ->setComment('Synced Order Table');
            $setup->getConnection()->createTable($table);
            $setup->getConnection()->addIndex(
                $setup->getTable('sportpat_order_sync_synced_order'),
                $setup->getIdxName(
                    $setup->getTable('sportpat_order_sync_synced_order'),
                    [
                        'lightspeed_order_url',
                        'status_details'
                    ],
                    AdapterInterface::INDEX_TYPE_FULLTEXT
                ),
                [
                    'lightspeed_order_url',
                    'status_details'
                ],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            );
        }
    }
}
