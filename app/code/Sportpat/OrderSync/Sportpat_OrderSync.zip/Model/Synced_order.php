<?php
namespace Sportpat\OrderSync\Model;

use Sportpat\OrderSync\Api\Data\Synced_orderInterface;
use Magento\Framework\Model\AbstractModel;
use Sportpat\OrderSync\Model\ResourceModel\Synced_order as Synced_orderResourceModel;

/**
 * @method \Sportpat\OrderSync\Model\ResourceModel\Synced_order _getResource()
 * @method \Sportpat\OrderSync\Model\ResourceModel\Synced_order getResource()
 */
class Synced_order extends AbstractModel implements Synced_orderInterface
{
    /**
     * Cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'sportpat_ordersync_synced_order';
    /**
     * Cache tag
     *
     * @var string
     */
    protected $_cacheTag = self::CACHE_TAG;
    /**
     * Event prefix
     *
     * @var string
     */
    protected $_eventPrefix = 'sportpat_ordersync_synced_order';
    /**
     * Event object
     *
     * @var string
     */
    protected $_eventObject = 'synced_order';
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(Synced_orderResourceModel::class);
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Page id
     *
     * @return array
     */
    public function getSynced_orderId()
    {
        return $this->getData(Synced_orderInterface::SYNCED_ORDER_ID);
    }

    /**
     * set Synced Order id
     *
     * @param  int $syncedOrderId
     * @return Synced_orderInterface
     */
    public function setSynced_orderId($syncedOrderId)
    {
        return $this->setData(Synced_orderInterface::SYNCED_ORDER_ID, $syncedOrderId);
    }

    /**
     * @param int $magentoOrderid
     * @return Synced_orderInterface
     */
    public function setMagentoOrderid($magentoOrderid)
    {
        return $this->setData(Synced_orderInterface::MAGENTO_ORDERID, $magentoOrderid);
    }

    /**
     * @return int
     */
    public function getMagentoOrderid()
    {
        return $this->getData(Synced_orderInterface::MAGENTO_ORDERID);
    }

    /**
     * @param int $lightspeedOrderid
     * @return Synced_orderInterface
     */
    public function setLightspeedOrderid($lightspeedOrderid)
    {
        return $this->setData(Synced_orderInterface::LIGHTSPEED_ORDERID, $lightspeedOrderid);
    }

    /**
     * @return int
     */
    public function getLightspeedOrderid()
    {
        return $this->getData(Synced_orderInterface::LIGHTSPEED_ORDERID);
    }

    /**
     * @param int $syncStatus
     * @return Synced_orderInterface
     */
    public function setSyncStatus($syncStatus)
    {
        return $this->setData(Synced_orderInterface::SYNC_STATUS, $syncStatus);
    }

    /**
     * @return int
     */
    public function getSyncStatus()
    {
        return $this->getData(Synced_orderInterface::SYNC_STATUS);
    }

    /**
     * @param string $lightspeedOrderUrl
     * @return Synced_orderInterface
     */
    public function setLightspeedOrderUrl($lightspeedOrderUrl)
    {
        return $this->setData(Synced_orderInterface::LIGHTSPEED_ORDER_URL, $lightspeedOrderUrl);
    }

    /**
     * @return string
     */
    public function getLightspeedOrderUrl()
    {
        return $this->getData(Synced_orderInterface::LIGHTSPEED_ORDER_URL);
    }

    /**
     * @param string $statusDetails
     * @return Synced_orderInterface
     */
    public function setStatusDetails($statusDetails)
    {
        return $this->setData(Synced_orderInterface::STATUS_DETAILS, $statusDetails);
    }

    /**
     * @return string
     */
    public function getStatusDetails()
    {
        return $this->getData(Synced_orderInterface::STATUS_DETAILS);
    }
}
