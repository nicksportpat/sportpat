<?php
namespace Sportpat\OrderSync\Model;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\Search\FilterGroup;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\ValidatorException;
use Sportpat\OrderSync\Api\Data\Synced_orderInterface;
use Sportpat\OrderSync\Api\Data\Synced_orderInterfaceFactory;
use Sportpat\OrderSync\Api\Data\Synced_orderSearchResultInterfaceFactory;
use Sportpat\OrderSync\Api\Synced_orderRepositoryInterface;
use Sportpat\OrderSync\Model\ResourceModel\Synced_order as Synced_orderResourceModel;
use Sportpat\OrderSync\Model\ResourceModel\Synced_order\Collection;
use Sportpat\OrderSync\Model\ResourceModel\Synced_order\CollectionFactory as Synced_orderCollectionFactory;

class Synced_orderRepository implements Synced_orderRepositoryInterface
{
    /**
     * Cached instances
     *
     * @var array
     */
    protected $instances = [];

    /**
     * Synced Order resource model
     *
     * @var Synced_orderResourceModel
     */
    protected $resource;

    /**
     * Synced Order collection factory
     *
     * @var Synced_orderCollectionFactory
     */
    protected $syncedOrderCollectionFactory;

    /**
     * Synced Order interface factory
     *
     * @var Synced_orderInterfaceFactory
     */
    protected $syncedOrderInterfaceFactory;

    /**
     * Data Object Helper
     *
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * Search result factory
     *
     * @var Synced_orderSearchResultInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * constructor
     * @param Synced_orderResourceModel $resource
     * @param Synced_orderCollectionFactory $syncedOrderCollectionFactory
     * @param Synced_ordernterfaceFactory $syncedOrderInterfaceFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param Synced_orderSearchResultInterfaceFactory $searchResultsFactory
     */
    public function __construct(
        Synced_orderResourceModel $resource,
        Synced_orderCollectionFactory $syncedOrderCollectionFactory,
        Synced_orderInterfaceFactory $syncedOrderInterfaceFactory,
        DataObjectHelper $dataObjectHelper,
        Synced_orderSearchResultInterfaceFactory $searchResultsFactory
    ) {
        $this->resource             = $resource;
        $this->syncedOrderCollectionFactory = $syncedOrderCollectionFactory;
        $this->syncedOrderInterfaceFactory  = $syncedOrderInterfaceFactory;
        $this->dataObjectHelper     = $dataObjectHelper;
        $this->searchResultsFactory = $searchResultsFactory;
    }

    /**
     * Save Synced Order.
     *
     * @param \Sportpat\OrderSync\Api\Data\Synced_orderInterface $syncedOrder
     * @return \Sportpat\OrderSync\Api\Data\Synced_orderInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(Synced_orderInterface $syncedOrder)
    {
        /** @var Synced_orderInterface|\Magento\Framework\Model\AbstractModel $syncedOrder */
        try {
            $this->resource->save($syncedOrder);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the Synced Order: %1',
                $exception->getMessage()
            ));
        }
        return $syncedOrder;
    }

    /**
     * Retrieve Synced Order
     *
     * @param int $syncedOrderId
     * @return \Sportpat\OrderSync\Api\Data\Synced_orderInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function get($syncedOrderId)
    {
        if (!isset($this->instances[$syncedOrderId])) {
            /** @var Synced_orderInterface|\Magento\Framework\Model\AbstractModel $syncedOrder */
            $syncedOrder = $this->syncedOrderInterfaceFactory->create();
            $this->resource->load($syncedOrder, $syncedOrderId);
            if (!$syncedOrder->getId()) {
                throw new NoSuchEntityException(__('Requested Synced Order doesn\'t exist'));
            }
            $this->instances[$syncedOrderId] = $syncedOrder;
        }
        return $this->instances[$syncedOrderId];
    }

    /**
     * Retrieve Synced Orders matching the specified criteria.
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return \Sportpat\OrderSync\Api\Data\Synced_orderSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var \Sportpat\OrderSync\Api\Data\Synced_orderSearchResultInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        /** @var \Sportpat\OrderSync\Model\ResourceModel\Synced_order\Collection $collection */
        $collection = $this->syncedOrderCollectionFactory->create();

        //Add filters from root filter group to the collection
        /** @var \Magento\Framework\Api\Search\FilterGroup $group */
        foreach ($searchCriteria->getFilterGroups() as $group) {
            $this->addFilterGroupToCollection($group, $collection);
        }
        $sortOrders = $searchCriteria->getSortOrders();
        /** @var SortOrder $sortOrder */
        if ($sortOrders) {
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $field = $sortOrder->getField();
                $collection->addOrder(
                    $field,
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? SortOrder::SORT_ASC : SortOrder::SORT_DESC
                );
            }
        } else {
            $collection->addOrder('main_table.' . Synced_orderInterface::SYNCED_ORDER_ID, SortOrder::SORT_ASC);
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());

        /** @var Synced_orderInterface[] $syncedOrders */
        $syncedOrders = [];
        /** @var \Sportpat\OrderSync\Model\Synced_order $syncedOrder */
        foreach ($collection as $syncedOrder) {
            /** @var Synced_orderInterface $syncedOrderDataObject */
            $syncedOrderDataObject = $this->syncedOrderInterfaceFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $syncedOrderDataObject,
                $syncedOrder->getData(),
                Synced_orderInterface::class
            );
            $syncedOrders[] = $syncedOrderDataObject;
        }
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults->setItems($syncedOrders);
    }

    /**
     * Delete Synced Order
     *
     * @param Synced_orderInterface $syncedOrder
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Synced_orderInterface $syncedOrder)
    {
        /** @var Synced_orderInterface|\Magento\Framework\Model\AbstractModel $syncedOrder */
        $id = $syncedOrder->getId();
        try {
            unset($this->instances[$id]);
            $this->resource->delete($syncedOrder);
        } catch (ValidatorException $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        } catch (\Exception $e) {
            throw new StateException(
                __('Unable to removeSynced Order %1', $id)
            );
        }
        unset($this->instances[$id]);
        return true;
    }

    /**
     * Delete Synced Order by ID.
     *
     * @param int $syncedOrderId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($syncedOrderId)
    {
        $syncedOrder = $this->get($syncedOrderId);
        return $this->delete($syncedOrder);
    }

    /**
     * Helper function that adds a FilterGroup to the collection.
     *
     * @param FilterGroup $filterGroup
     * @param Collection $collection
     * @return $this
     * @throws \Magento\Framework\Exception\InputException
     */
    protected function addFilterGroupToCollection(
        FilterGroup $filterGroup,
        Collection $collection
    ) {
        $fields = [];
        $conditions = [];
        foreach ($filterGroup->getFilters() as $filter) {
            $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
            $fields[] = $filter->getField();
            $conditions[] = [$condition => $filter->getValue()];
        }
        if ($fields) {
            $collection->addFieldToFilter($fields, $conditions);
        }
        return $this;
    }

    /**
     * clear caches instances
     * @return void
     */
    public function clear()
    {
        $this->instances = [];
    }
}
