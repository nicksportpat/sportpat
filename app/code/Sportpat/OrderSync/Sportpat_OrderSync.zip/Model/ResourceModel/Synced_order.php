<?php
namespace Sportpat\OrderSync\Model\ResourceModel;

class SyncedOrder extends AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('sportpat_order_sync_synced_order', 'synced_order_id');
    }
}
