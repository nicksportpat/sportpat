<?php
namespace Sportpat\OrderSync\Model\ResourceModel\Synced_order;

use Sportpat\OrderSync\Model\Synced_order;
use Sportpat\OrderSync\Model\ResourceModel\AbstractCollection;

/**
 * @api
 */
class Collection extends AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            Synced_order::class,
            \Sportpat\OrderSync\Model\ResourceModel\Synced_order::class
        );
    }
}
