<?php
namespace Sportpat\OrderSync\Model\SyncedOrder\Source;

use Magento\Framework\Option\ArrayInterface;

class SyncStatus implements ArrayInterface
{
    const PENDING = 1;
    const SYNCED = 2;
    const ERROR = 3;

    /**
     * to option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => self::PENDING,
                'label' => __('PENDING')
            ],
            [
                'value' => self::SYNCED,
                'label' => __('SYNCED')
            ],
            [
                'value' => self::ERROR,
                'label' => __('ERROR')
            ],
        ];
        return $options;
    }
}
