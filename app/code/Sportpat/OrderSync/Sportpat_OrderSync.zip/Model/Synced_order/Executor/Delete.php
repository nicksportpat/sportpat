<?php
namespace Sportpat\OrderSync\Model\Synced_order\Executor;

use Sportpat\OrderSync\Api\SyncedOrderRepositoryInterface;
use Sportpat\OrderSync\Api\ExecutorInterface;

class Delete implements ExecutorInterface
{
    /**
     * @var Synced_orderRepositoryInterface
     */
    private $syncedOrderRepository;

    /**
     * Delete constructor.
     * @param Synced_orderRepositoryInterface $syncedOrderRepository
     */
    public function __construct(
        Synced_orderRepositoryInterface $syncedOrderRepository
    ) {
        $this->syncedOrderRepository = $syncedOrderRepository;
    }

    /**
     * @param int $id
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute($id)
    {
        $this->syncedOrderRepository->deleteById($id);
    }
}
