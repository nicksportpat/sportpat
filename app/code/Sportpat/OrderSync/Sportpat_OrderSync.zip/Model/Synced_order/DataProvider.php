<?php
namespace Sportpat\OrderSync\Model\Synced_order;

use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Sportpat\OrderSync\Model\ResourceModel\SyncedOrder\CollectionFactory as SyncedOrderCollectionFactory;

class DataProvider extends AbstractDataProvider
{
    /**
     * Loaded data cache
     *
     * @var array
     */
    protected $loadedData;

    /**
     * Data persistor
     *
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param Synced_orderCollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        Synced_orderCollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \Sportpat\OrderSync\Model\Synced_order $syncedOrder */
        foreach ($items as $syncedOrder) {
            $this->loadedData[$syncedOrder->getId()] = $syncedOrder->getData();
        }
        $data = $this->dataPersistor->get('sportpat_order_sync_synced_order');
        if (!empty($data)) {
            $syncedOrder = $this->collection->getNewEmptyItem();
            $syncedOrder->setData($data);
            $this->loadedData[$syncedOrder->getId()] = $syncedOrder->getData();
            $this->dataPersistor->clear('sportpat_order_sync_synced_order');
        }
        return $this->loadedData;
    }
}
