<?php
namespace Sportpat\OrderSync\Block\Adminhtml\Button\Synced_order;

use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class Delete implements ButtonProviderInterface
{
    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var UrlInterface
     */
    private $url;

    /**
     * Delete constructor.
     * @param Registry $registry
     * @param UrlInterface $url
     */
    public function __construct(Registry $registry, UrlInterface $url)
    {
        $this->registry = $registry;
        $this->url = $url;
    }

    /**
     * get button data
     *
     * @return array
     */
    public function getButtonData()
    {
        $data = [];
        if ($this->getSynced_orderId()) {
            $data = [
                'label' => __('Delete Synced Order'),
                'class' => 'delete',
                'on_click' => 'deleteConfirm(\'' . __(
                    'Are you sure you want to do this?'
                ) . '\', \'' . $this->getDeleteUrl() . '\')',
                'sort_order' => 20,
            ];
        }
        return $data;
    }

    /**
     * @return \Sportpat\OrderSync\Api\Data\Synced_orderInterface | null
     */
    private function getSynced_order()
    {
        return $this->registry->registry('current_synced_order');
    }

    /**
     * @return int|null
     */
    private function getSynced_orderId()
    {
        $syncedOrder = $this->getSynced_order();
        return ($syncedOrder) ? $syncedOrder->getId() : null;
    }

    /**
     * @return string
     */
    public function getDeleteUrl()
    {
        return $this->url->getUrl(
            '*/*/delete',
            [
                'synced_order_id' => $this->getsyncedOrderId()
            ]
        );
    }
}
