<?php
namespace Sportpat\OrderSync\Api;

use Sportpat\OrderSync\Api\Data\Synced_orderInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * @api
 */
interface Synced_orderRepositoryInterface
{
    /**
     * @param Synced_orderInterface $synced_order
     * @return Synced_orderInterface
     */
    public function save(Synced_orderInterface $synced_order);

    /**
     * @param $id
     * @return Synced_orderInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function get($id);

    /**
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Sportpat\OrderSync\Api\Data\Synced_orderSearchResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @param Synced_orderInterface $synced_order
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Synced_orderInterface $synced_order);

    /**
     * @param int $synced_orderId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($synced_orderId);

    /**
     * clear caches instances
     * @return void
     */
    public function clear();
}
