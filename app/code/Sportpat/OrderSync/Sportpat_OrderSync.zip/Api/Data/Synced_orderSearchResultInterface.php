<?php
namespace Sportpat\OrderSync\Api\Data;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * @api
 */
interface Synced_orderSearchResultInterface
{
    /**
     * get items
     *
     * @return \Sportpat\OrderSync\Api\Data\Synced_orderInterface[]
     */
    public function getItems();

    /**
     * Set items
     *
     * @param \Sportpat\OrderSync\Api\Data\Synced_orderInterface[] $items
     * @return $this
     */
    public function setItems(array $items);

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return $this
     */
    public function setSearchCriteria(SearchCriteriaInterface $searchCriteria);

    /**
     * @param int $count
     * @return $this
     */
    public function setTotalCount($count);
}
