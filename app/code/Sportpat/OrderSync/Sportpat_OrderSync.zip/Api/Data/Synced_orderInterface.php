<?php
namespace Sportpat\OrderSync\Api\Data;

/**
 * @api
 */
interface Synced_orderInterface
{
    const SYNCED_ORDER_ID = 'synced_order_id';
    const MAGENTO_ORDERID = 'magento_orderid';
    const LIGHTSPEED_ORDERID = 'lightspeed_orderid';
    const SYNC_STATUS = 'sync_status';
    const LIGHTSPEED_ORDER_URL = 'lightspeed_order_url';
    const STATUS_DETAILS = 'status_details';
    /**
     * @param int $id
     * @return Synced_orderInterface
     */
    public function setId($id);

    /**
     * @return int
     */
    public function getId();

    /**
     * @param int $id
     * @return Synced_orderInterface
     */
    public function setSynced_orderId($id);

    /**
     * @return int
     */
    public function getSynced_orderId();

    /**
     * @param int $magentoOrderid
     * @return Synced_orderInterface
     */
    public function setMagentoOrderid($magentoOrderid);

    /**
     * @return int
     */
    public function getMagentoOrderid();
    /**
     * @param int $lightspeedOrderid
     * @return Synced_orderInterface
     */
    public function setLightspeedOrderid($lightspeedOrderid);

    /**
     * @return int
     */
    public function getLightspeedOrderid();
    /**
     * @param int $syncStatus
     * @return Synced_orderInterface
     */
    public function setSyncStatus($syncStatus);

    /**
     * @return int
     */
    public function getSyncStatus();
    /**
     * @param string $lightspeedOrderUrl
     * @return Synced_orderInterface
     */
    public function setLightspeedOrderUrl($lightspeedOrderUrl);

    /**
     * @return string
     */
    public function getLightspeedOrderUrl();
    /**
     * @param string $statusDetails
     * @return Synced_orderInterface
     */
    public function setStatusDetails($statusDetails);

    /**
     * @return string
     */
    public function getStatusDetails();
}
