<?php

namespace Nick\Algoliasearch\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\CatalogRule\Model\Rule as RuleModel;

class PriceIndexObserver implements ObserverInterface
{

    protected $_ruleModel;
    protected $_productFactory;

    public function __construct(RuleModel $ruleModel,\Magento\Catalog\Model\ProductFactory $productFactory)
    {
        // Observer initialization code...
        // You can use dependency injection to get any class this observer may need.

        $this->_ruleModel = $ruleModel;
        $this->_productFactory = $productFactory;

    }

    public function execute(Observer $observer)
    {
        // Observer execution code...
        // Here you can modify frontend configuration

        // Example:
        // productsSettings = $observer->getData('index_settings');
        // $productsSettings['foo'] = 'bar';

        $product = $observer->getData('productObject');
        $productRecord = $observer->getData('custom_data');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();


        $finalPrice = "";
        $pid = $product->getID();

        if($product->getTypeId() == "configurable") {
            $configProduct = $objectManager->create('Magento\Catalog\Model\Product')->load($pid);


            $_c = $configProduct->getTypeInstance()->getUsedProducts($configProduct);

            $childid = 0;

            foreach ($_c as $c) {

                if ($childid == 0) {
                    $childid = $c->getID();
                } else {
                    continue;
                }

            }


            $sql = "SELECT * FROM catalogrule_product where product_id = ${childid}";
            echo $sql . "\n";


            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $result = $connection->fetchAll($sql);


            if (is_array($result) && isset($result[0])) {
                print_r($result[0]);
                $productRecord['price_info'] = [
                    "regular" => $result[0]["action_amount"],
                    "final" => $finalPrice,
                    "isSpecialPrice" => ""
                ];

            }
        } else {
            $productRecord['price_info'] = [
                "regular"=>1,
                "final" =>1,
                "isSpecialPrice"=>""
            ];
        }



        $regPrice = $product->getFinalPrice();



        if($regPrice == 0 && $product->getTypeId() == "configurable" || $productRecord['in_stock'] == 0) {
            $productRecord['in_stock'] = 0;
            $productRecord['visibility_search'] = 0;
            $productRecord['visibility_catalog'] = 0;

        }



    }

   public function checkIsSpecialPrice($price, $finalPrice) {

        $special = false;
        if($finalPrice !== NULL && $price != $finalPrice &&
        $price > $finalPrice) {
            $special = true;
        }

        return $special;


   }
}

