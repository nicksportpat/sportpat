console.log('Custom autocomplete.js loaded');
